# Applied coordinate and history status

Current canonical stage67:142223 finite histories;168edges/167pointuses, no source observations/rejections/events.77newfinite histories add18241/15978/14143. G17 remains inherited65typed5495only2002, new67UID/event/receiver credit0; representative points do not assert historical coordinates.

Applied5027 primary2010claims4917credited/110outside preserve raw State. Effective primary99.272256120%/99.244764692%/99.521716956%; ordinary-only99% unmet. Same-State42histories>5km/0>100km, raw269positive/227reverse growthflags unsmoothed. Unresolvedraw2010735, quality0/3/0, unknownpoint1740/2090/300 retained.133unknown sex fields remain NULL.

One canonical build/standalone/exactUIDregionalchecks passed158output hashes,465928observations and446139narrowpoint claims. Source2002signedexcess757/effective2010deficit305303 retained. No clamping, accuracyCI, full municipal audit or GitHub upload. See combined67_validation_receipt.json/output_hash_manifest.json; source65export-only OOM recovery remains historical.
